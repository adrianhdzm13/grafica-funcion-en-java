import metodosnum.Integracion_UI;
/**
 *
 * @author 
 */
public class MetodosNumericos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Integracion_UI vIntegrales = new Integracion_UI(5);
        vIntegrales.setVisible(true);
        vIntegrales.setLocationRelativeTo(null);
    }
}
