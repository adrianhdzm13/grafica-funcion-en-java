package controller;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import model.Eventos;
import view.fPrincipal;

public class PrincipalController extends Eventos {

    private fPrincipal fp;
    JPanel panel;

    public PrincipalController(fPrincipal fp) {
        this.fp = fp;
        init();
    }

    private void init() {
        //formulario
        this.fp.setVisible(true);
        this.fp.setLocationRelativeTo(null);
        //eventos
        this.fp.btnCalcular.addMouseListener(this);
        this.fp.txtResultado.addMouseListener(this);
        //ejecutar Boton Calculat
        //panel = new Grafica3();
        panel = new GraficaController(fp);
        graficar();
        calcular(1);
    }

    private void graficar() {
        //panel = new Grafica3();
        //fp.grafica.setSize(800, 900);
        panel.setPreferredSize(new Dimension(fp.grafica.getWidth() + 20, fp.grafica.getHeight()));
        fp.grafica.add(panel);
        panel.setCursor(Cursor.getPredefinedCursor(12));
        panel.repaint();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (this.fp.btnCalcular.equals(e.getSource())) {
            graficar();
            calcular(1);
        }// else if (e.getSource().equals(this.fp.txtResultado)) {
        else {
            JOptionPane.showMessageDialog(null, this.fp.txtResultado.getText(), "Derivada", 1);
            //this.fp.txtResultado.setText(". . .");
        }
    }
    public static String r;

    private void calcular(int i) {
        r = DerivadaController.Derivar(this.fp.txtFuncion.getText());
        this.fp.txtResultado.setText(resultado(r));
    }

    private String resultado(String result) {
        int letra = 0;
        if (result.length() >= 151) {
            letra = 9;
        } else {
            letra = 11;
        }
        //danger #dc3545
        String html = ""
                + "<html>"
                + "<head><style></style>"
                + "</head>"
                + "<body>"
                + "<div style='padding-top:7px;background:#713545;height:25px; width:616px;text-align:center;'><span style='color:#8fC9CA; font-size: " + letra + "px;'>Derivada: " + result.replace("sqrt", "raíz") + "<span>"
                + "<div>"
                + "</body>"
                + "</html>";
        return html;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        panel.repaint();
    }
}
